<div class="row gx-3">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <h5 class="card-title">Tambah Data Anak</h5>
      </div>
      <div class="card-body">

        <form wire:submit.prevent="store" enctype="multipart/form-data">
          <!-- Nama Anak -->
          <div class="mb-3">
            <label class="form-label">Nama Anak <span class="text-danger">*</span></label>
            <input type="text" class="form-control" wire:model.live="nama_anak" placeholder="Masukkan nama anak">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- Tanggal Lahir -->
          <div class="mb-3">
            <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
            <input type="date" class="form-control" wire:model="tanggal_lahir">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- Jenis Kelamin -->
          <div class="mb-3">
            <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
            <div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" wire:model="jenis_kelamin" value="L">
                <label class="form-check-label">Laki-laki</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" wire:model="jenis_kelamin" value="P">
                <label class="form-check-label">Perempuan</label>
              </div>
            </div>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <hr>

          <!-- Nama Orang Tua -->
          <div class="mb-3">
            <label class="form-label">Nama Orang Tua <span class="text-danger">*</span></label>
            <input type="text" class="form-control" wire:model="nama_ibu" placeholder="Masukkan nama orang tua">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- Email Orang Tua -->
          <div class="mb-3">
            <label class="form-label">Email Orang Tua <span class="text-danger">*</span></label>
            <input type="email" class="form-control" wire:model.live="email" placeholder="Masukkan email orang tua">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- No HP Orang Tua -->
          <div class="mb-3">
            <label class="form-label">No HP Orang Tua</label>
            <input type="text" class="form-control" wire:model.live="no_hp" placeholder="Masukkan nomor HP">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- Alamat -->
          <div class="mb-3">
            <label class="form-label">Alamat</label>
            <input type="text" class="form-control" wire:model.live="alamat" placeholder="Masukkan alamat">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- Foto Orang Tua -->
          <div class="mb-3">
            <label class="form-label">Foto Orang Tua (Max: 1M)</label>
            <input type="file" class="form-control" wire:model.live="foto" accept=".jpg,.jpeg,.png">
            <!--[if BLOCK]><![endif]--><?php if($foto): ?>
              <img src="<?php echo e($foto->temporaryUrl()); ?>" class="img-thumbnail mt-2" width="120">
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <!-- Tombol -->
          <div class="d-flex gap-2 justify-content-end">
            <a href="<?php echo e(route('anak.index')); ?>" class="btn btn-outline-secondary">Batal</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/anak/anak-create.blade.php ENDPATH**/ ?>