<div>
            <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="alert bg-success text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('error')): ?>
            <div class="alert bg-danger text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-close-circle-line fs-3 me-2 lh-1"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('warning')): ?>
            <div class="alert bg-warning text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-alert-line fs-3 me-2 lh-1"></i> <?php echo e(session('warning')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
    <?php
        $mapBBU = [
            'Gizi Baik'   => 'success',
            'Gizi Kurang' => 'warning',
            'Gizi Buruk'  => 'danger',
            'Gizi Lebih'  => 'warning',
        ];
        $mapTBU = [
            'Normal' => 'success',
            'Pendek' => 'warning',
            'Tinggi' => 'primary',
        ];
        $clsBBU = $mapBBU[$pemeriksaan->status_bbu ?? ''] ?? 'secondary';
        $clsTBU = $mapTBU[$pemeriksaan->status_tbu ?? ''] ?? 'secondary';
    ?>

    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
        <div>
            <h4 class="mb-1">
                Detail Pemeriksaan — <?php echo e($pemeriksaan->anak->nama); ?>

            </h4>
            <div class="text-muted small">
                <?php echo e(\Carbon\Carbon::parse($pemeriksaan->tanggal)->format('d M Y')); ?>

                • Umur: <?php echo e(hitungUmur($pemeriksaan->anak->tanggal_lahir)); ?>

                • Petugas: <strong><?php echo e($pemeriksaan->petugas->name ?? '-'); ?></strong>
            </div>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('pemeriksaan.index')); ?>" class="btn btn-outline-secondary">
                <i class="ri-arrow-left-line"></i> Kembali
            </a>
            <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                <a href="<?php echo e(route('tindak-lanjut.create', $pemeriksaan->id)); ?>" class="btn btn-primary">
                    <i class="ri-add-line"></i> Tambah Tindak Lanjut
                </a>
                <a href="<?php echo e(route('pemeriksaan.edit', $pemeriksaan->id)); ?>" class="btn btn-warning">
                    <i class="ri-edit-2-line"></i> Edit Pemeriksaan
                </a>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    
    <div class="d-flex flex-wrap gap-2 mb-4">
        <span class="badge bg-<?php echo e($clsBBU); ?>">Status BB/U: <?php echo e($pemeriksaan->status_bbu ?? '-'); ?></span>
        <span class="badge bg-<?php echo e($clsTBU); ?>">Status TB/U: <?php echo e($pemeriksaan->status_tbu ?? '-'); ?></span>

        <!--[if BLOCK]><![endif]--><?php if($pemeriksaan->perubahan_bb): ?>
            <span class="badge bg-light text-dark border">
                <!--[if BLOCK]><![endif]--><?php if($pemeriksaan->perubahan_bb === 'Naik'): ?>
                    <i class="ri-arrow-up-line"></i>
                <?php elseif($pemeriksaan->perubahan_bb === 'Turun'): ?>
                    <i class="ri-arrow-down-line"></i>
                <?php else: ?>
                    <i class="ri-subtract-line"></i>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                Δ BB: <?php echo e($pemeriksaan->perubahan_bb); ?>

            </span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if($pemeriksaan->perubahan_tb): ?>
            <span class="badge bg-light text-dark border">
                <!--[if BLOCK]><![endif]--><?php if($pemeriksaan->perubahan_tb === 'Naik'): ?>
                    <i class="ri-arrow-up-line"></i>
                <?php elseif($pemeriksaan->perubahan_tb === 'Turun'): ?>
                    <i class="ri-arrow-down-line"></i>
                <?php else: ?>
                    <i class="ri-subtract-line"></i>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                Δ TB: <?php echo e($pemeriksaan->perubahan_tb); ?>

            </span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0">Data Pemeriksaan</h5>
        </div>
        <div class="card-body">
            <table class="table table-bordered m-0">
                <tr>
                    <th style="width: 240px;">Anak</th>
                    <td><?php echo e($pemeriksaan->anak->nama); ?> (<?php echo e(hitungUmur($pemeriksaan->anak->tanggal_lahir)); ?>)</td>
                </tr>
                <tr>
                    <th>Tanggal</th>
                    <td><?php echo e(\Carbon\Carbon::parse($pemeriksaan->tanggal)->format('d M Y')); ?></td>
                </tr>
                <tr>
                    <th>Berat Badan</th>
                    <td><?php echo e($pemeriksaan->berat_badan); ?> kg <span class="badge bg-<?php echo e($clsBBU); ?>"><?php echo e($pemeriksaan->status_bbu ?? '-'); ?></span></td>
                </tr>
                <tr>
                    <th>Tinggi Badan</th>
                    <td><?php echo e($pemeriksaan->tinggi_badan); ?> cm <span class="badge bg-<?php echo e($clsTBU); ?>"><?php echo e($pemeriksaan->status_tbu ?? '-'); ?></span></td>
                </tr>
                <tr>
                    <th>Lingkar Kepala</th>
                    <td><?php echo e($pemeriksaan->lingkar_kepala ?? '-'); ?> <?php echo e($pemeriksaan->lingkar_kepala ? 'cm' : ''); ?></td>
                </tr>
                <tr>
                    <th>Lingkar Lengan</th>
                    <td><?php echo e($pemeriksaan->lingkar_lengan ?? '-'); ?> <?php echo e($pemeriksaan->lingkar_lengan ? 'cm' : ''); ?></td>
                </tr>
                <tr>
                    <th>Δ Berat / Tinggi</th>
                    <td>
                        <span class="me-3">BB: <?php echo e($pemeriksaan->perubahan_bb ?? '-'); ?></span>
                        <span>TB: <?php echo e($pemeriksaan->perubahan_tb ?? '-'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>Keluhan</th>
                    <td><?php echo e($pemeriksaan->keluhan ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Diagnosa / Catatan</th>
                    <td><?php echo e($pemeriksaan->catatan ?? '-'); ?></td>
                </tr>
                <tr>
                    <th>Petugas</th>
                    <td><?php echo e($pemeriksaan->petugas->name ?? '-'); ?></td>
                </tr>
            </table>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h5 class="card-title mb-0">Tindak Lanjut</h5>
        </div>
        <div class="card-body pt-0">
            <div class="table-responsive">
                <table class="table align-middle table-striped table-borderless m-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 60px;">#</th>
                            <th style="width: 140px;">Tanggal</th>
                            <th style="width: 180px;">Jenis</th>
                            <th>Keterangan</th>
                            <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                                <th style="width: 160px;" class="text-end">Aksi</th>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tindakLanjut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($i+1); ?></td>
                                <td><?php echo e($tl->tanggal ? \Carbon\Carbon::parse($tl->tanggal)->format('d M Y') : '-'); ?></td>
                                <td><span class="badge bg-secondary"><?php echo e($tl->jenis); ?></span></td>
                                <td class="text-break"><?php echo e($tl->keterangan ?? '-'); ?></td>
                                <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                                    <td class="text-end">
                                        <a href="<?php echo e(route('tindak-lanjut.edit', $tl->id)); ?>" class="btn btn-sm btn-warning">
                                            <i class="ri-edit-2-line"></i>
                                        </a>
                                        <button wire:click="deleteConfirmation(<?php echo e($tl->id); ?>)" class="btn btn-sm btn-danger">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">Belum ada tindak lanjut.</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/pemeriksaan/pemeriksaan-show.blade.php ENDPATH**/ ?>