<div class="row gx-3">
    <div class="col-12">
        <div class="card mb-3">
            <div class="card-body mh-190 d-flex flex-column">

                <h5 class="fw-bold mb-3">Pesan Tindak Lanjut</h5>

                <div class="chat-messages flex-grow-1" style="max-height:350px; overflow-y:auto;">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $tindakLanjut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="d-flex mb-3 <?php echo e($tl->is_read ? 'justify-content-start' : 'justify-content-end'); ?>">
                            <div class="p-3 rounded-4 shadow-sm 
                                <?php echo e($tl->is_read ? 'bg-light text-dark' : 'bg-primary text-white'); ?>"
                                style="max-width: 100%;">

                                                                
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <small class="fw-semibold"><?php echo e($tl->jenis ?? '-'); ?></small>
                                    <small class="<?php echo e($tl->is_read ? 'text-muted' : 'text-white-50'); ?>">
                                        <?php echo e($tl->created_at?->format('d-m-Y') ?? '-'); ?>

                                    </small>
                                </div>

                                <!--[if BLOCK]><![endif]--><?php if($tl->pemeriksaan): ?>
                                    <div class="small mb-2 <?php echo e($tl->is_read ? 'text-muted' : 'text-white-75'); ?>">
                                        <div>BB: <?php echo e($tl->pemeriksaan->berat_badan); ?> kg, 
                                             TB: <?php echo e($tl->pemeriksaan->tinggi_badan); ?> cm</div>
                                        <div>Status: <?php echo e($tl->pemeriksaan->status_bbu); ?> / <?php echo e($tl->pemeriksaan->status_tbu); ?></div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <hr>

                                
                                <!--[if BLOCK]><![endif]--><?php if($tl->tanggal): ?>
                                    <?php
                                        $hari    = \Carbon\Carbon::parse($tl->tanggal_kunjungan)->translatedFormat('l'); 
                                        $tanggal = \Carbon\Carbon::parse($tl->tanggal_kunjungan)->format('d-m-Y');       
                                        $jam     = \Carbon\Carbon::parse($tl->tanggal_kunjungan)->format('H:i');         
                                    ?>

                                    <div class="small fst-italic <?php echo e($tl->is_read ? 'text-muted' : 'text-white-75'); ?>">
                                    <div class="lh-sm"><?php echo e($tl->keterangan ?? '-'); ?></div>
                                        <ul class="mb-0 ps-3">
                                            <li>Hari: <strong><?php echo e($hari); ?></strong></li>
                                            <li>Tanggal: <strong><?php echo e($tanggal); ?></strong></li>
                                            <li>Jam: <strong><?php echo e($jam); ?></strong></li>
                                        </ul>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


                                
                                <!--[if BLOCK]><![endif]--><?php if(!$tl->is_read): ?>
                                    <div class="text-end mt-2">
                                        <button wire:click="markAsRead(<?php echo e($tl->id); ?>)"
                                            class="btn btn-sm btn-light text-primary px-2 py-0">
                                            <i class="bi bi-check2-circle me-1"></i> Tandai sudah dibaca
                                        </button>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted text-center">Belum ada tindak lanjut.</p>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/orang-tua/tindak-lanjut-chat.blade.php ENDPATH**/ ?>