<!-- Row starts -->
<div class="row gx-3">
    <div class="col-sm-12">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="alert bg-success text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i style="color: white"
                    class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i><?php echo e(session('success')); ?>.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('error')): ?>
            <div class="alert bg-danger text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i style="color: white"
                    class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i><?php echo e(session('error')); ?>.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('warning')): ?>
            <div class="alert bg-warning text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i style="color: white"
                    class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i><?php echo e(session('warning')); ?>.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="card-title mb-0">List Riwayat Posyandu <span class="badge border border-primary text-primary"><?php echo e($anak->nama); ?></span> </h5>
                <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                    <div class="d-flex gap-2">
                        <input type="text" class="form-control" 
                            placeholder="Cari..."
                            wire:model.live="search">

                        <a href="<?php echo e(route('posyandu.create', $anak->id)); ?>" class="btn btn-primary">Tambah</a>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="card-body pt-0">

                <!-- Table starts -->
                <div class="table-responsive">
                    <table id="scrollVertical" class="table truncate m-0 align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Berat Badan (kg)</th>
                                <th>Tinggi Badan (cm)</th>
                                <th>Lingkar Kepala (cm)</th>
                                <th>Lingkar Lengan (cm)</th>
                                <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                                    <th>Aksi</th>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tr>
                        </thead>

                        <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($r->tanggal); ?></td>
                                <td><?php echo e($r->berat_badan); ?></td>
                                <td><?php echo e($r->tinggi_badan); ?></td>
                                <td><?php echo e($r->lingkar_kepala); ?></td>
                                <td><?php echo e($r->lingkar_lengan); ?></td>
                                <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                                <td>
                                    <a href="<?php echo e(route('posyandu.edit', $r->id)); ?>" class="btn btn-success btn-sm">
                                        <i class="ri-edit-box-line"></i>
                                    </a>
                                        <button type="button" wire:click.prevent="deleteConfirmation('<?php echo e($r->id); ?>')" class="btn btn-danger btn-sm" data-bs-toggle="tooltip" data-bs-placement="top"
                                            data-bs-title="Hapus Data">
                                            <i class="ri-delete-bin-line"></i>
                                        </button>
                                        
                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="6">Belum ada data</td></tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
                <!-- Table ends -->

            </div>
        </div>
    </div>
</div>
<!-- Row ends --><?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/riwayat-posyandu/posyandu-index.blade.php ENDPATH**/ ?>