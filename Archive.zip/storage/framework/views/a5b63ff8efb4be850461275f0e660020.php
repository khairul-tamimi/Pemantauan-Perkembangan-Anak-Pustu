<div class="card">
    <div class="card-header">
        <h5 class="card-title">Edit Tindak Lanjut</h5>
    </div>
    <div class="card-body">
        <form wire:submit.prevent="update">
            <div class="mb-3">
                <label class="form-label">Jenis</label>
                <select wire:model="jenis" class="form-control">
                    <option value="Kunjungan Rumah">Kunjungan Rumah</option>
                    <option value="PMT">PMT</option>
                    <option value="Rujuk Puskesmas">Rujuk Puskesmas</option>
                    <option value="Lainnya">Lainnya</option>
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="mb-3">
                <label class="form-label">Tanggal</label>
                <input type="datetime-local" wire:model="tanggal" class="form-control">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="mb-3">
                <label class="form-label">Keterangan</label>
                <textarea wire:model="keterangan" class="form-control"></textarea>
            </div>

            <div class="d-flex justify-content-end gap-2">
                <a href="<?php echo e(route('pemeriksaan.show', $pemeriksaan_id)); ?>" class="btn btn-secondary">Batal</a>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/tindak-lanjut/tindak-lanjut-edit.blade.php ENDPATH**/ ?>