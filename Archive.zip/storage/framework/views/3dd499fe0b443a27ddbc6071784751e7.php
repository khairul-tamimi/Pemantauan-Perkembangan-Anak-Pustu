

<!-- Row starts -->
<div class="row gx-3">
    <div class="col-sm-12">

        
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="card-title mb-0">Tambah Jadwal Pemeriksaan</h5>
            </div>

            <div class="card-body">
                <form wire:submit.prevent="update">
                    <div class="row g-3">

                        <div class="col-md-12">
                            <select wire:model="anak_id" class="form-select">
                                <option value="">-- Pilih Anak --</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $anaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($anak->id); ?>"><?php echo e($anak->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="col-md-12">
                            <label>Tanggal Kunjungan</label>
                            <input type="date" wire:model="tanggal_kunjungan" class="form-control">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>


                    <div class="mt-4 d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('standar-pertumbuhan.index')); ?>" class="btn btn-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<!-- Row ends -->
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/jadwal-kunjungan/jadwal-kunjungan-edit.blade.php ENDPATH**/ ?>