<div class="row gx-3">
    <div class="col-sm-12">

        
        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="alert bg-success text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('error')): ?>
            <div class="alert bg-danger text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-close-circle-line fs-3 me-2 lh-1"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('warning')): ?>
            <div class="alert bg-warning text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-alert-line fs-3 me-2 lh-1"></i> <?php echo e(session('warning')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <div class="card">
            <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Daftar Pemeriksaan</h5>
                    <a href="<?php echo e(route('pemeriksaan.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="ri-add-line me-1"></i> Tambah Pemeriksaan
                    </a>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="card-body">
                <div class="mb-3">
                    <label for="anak_id" class="form-label">Pilih Anak</label>
                    <select wire:model.live="anak_id" id="anak_id" class="form-control">
                        <option value="">-- Pilih Anak --</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $anakList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($anak->id); ?>"><?php echo e($anak->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                </div>

                <!--[if BLOCK]><![endif]--><?php if($anak_id): ?>
                    <h6 class="mb-3">
                        Riwayat Pemeriksaan: 
                        <strong><?php echo e(\App\Models\Anak::find($anak_id)->nama); ?> | Umur: <span class="badge border border-primary text-primary"><?php echo e(hitungUmur(\App\Models\Anak::find($anak_id)->tanggal_lahir)); ?></span></strong>
                    </h6>

                    <div class="table-responsive">
                        <table class="table m-0 align-middle dataTable no-footer">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Tanggal</th>
                                    <th>BB (kg) | BB</th>
                                    <th>TB (cm) | TB</th>
                                    <th>Status BB</th>
                                    <th>Status TB</th>
                                    <th>Lingkar Kepala | LK</th>
                                    <th>Lingkar Lengan | LL</th>
                                    <th>Status LK</th>
                                    <th>Status LL</th>
                                    <th>Petugas</th>
                                    <th style="width:120px">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $pemeriksaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $periksa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($periksa->tanggal); ?> | Umur: <?php echo e(hitungUmur($periksa->anak->tanggal_lahir, $periksa->tanggal)); ?></td>
                                        <td><?php echo e($periksa->berat_badan); ?> | <?php echo e($periksa->perubahan_bb ?? '-'); ?></td>
                                        <td><?php echo e($periksa->tinggi_badan); ?> | <?php echo e($periksa->perubahan_tb ?? '-'); ?></td>
                                        <td><?php echo e($periksa->status_bbu ?? '-'); ?></td>
                                        <td><?php echo e($periksa->status_tbu ?? '-'); ?></td>
                                        <td><?php echo e($periksa->lingkar_kepala); ?> | <?php echo e($periksa->perubahan_lk ?? '-'); ?></td>
                                        <td><?php echo e($periksa->lingkar_lengan); ?> | <?php echo e($periksa->perubahan_ll ?? '-'); ?></td>
                                        <td><?php echo e($periksa->status_lk ?? '-'); ?></td>
                                        <td><?php echo e($periksa->status_ll ?? '-'); ?></td>
                                        <td><?php echo e($periksa->petugas?->name ?? '-'); ?></td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('pemeriksaan.show', $periksa->id)); ?>" 
                                            class="btn btn-sm <?php echo e($periksa->tindakLanjut->isNotEmpty() ? 'btn-info' : 'btn-success'); ?>" 
                                            data-bs-toggle="tooltip" 
                                            title="Detail">
                                                <i class="ri-eye-line"></i>
                                            </a>

                                             <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin', 'petugas'])): ?>
                                                <a href="<?php echo e(route('pemeriksaan.edit', $periksa->id)); ?>" 
                                                class="btn btn-warning btn-sm" data-bs-toggle="tooltip" title="Edit">
                                                    <i class="ri-edit-box-line"></i>
                                                </a>
                                                <button type="button" 
                                                        wire:click.prevent="deleteConfirmation('<?php echo e($periksa->id); ?>')" 
                                                        class="btn btn-danger btn-sm" 
                                                        data-bs-toggle="tooltip" 
                                                        title="Hapus">
                                                    <i class="ri-delete-bin-line"></i>
                                                </button>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="11" class="text-center">Belum ada pemeriksaan</td>
                                    </tr>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/pemeriksaan/pemeriksaan-index.blade.php ENDPATH**/ ?>