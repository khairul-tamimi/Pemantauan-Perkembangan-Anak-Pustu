<div class="row gx-3">
    <div class="col-xxl-12 col-sm-12">
        <div class="card mb-3 bg-4 shadow-sm">
            <div class="card-body">
                <div class="row gx-3 align-items-center mb-3">
                    <div class="col-sm-9">
                        <div class="text-primary">
                            <h4 class="mb-1">Selamat Datang</h4>
                            <h6 class="fw-normal mb-0"><?php echo e(Auth::user()->name); ?></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'petugas'): ?>
        <div class="col-xxl-12 col-sm-12">
            <div class="row gx-3">
                <div class="col-md-3 mb-3">
                    <div class="card h-100 bg-success text-white shadow-sm">
                        <div class="card-body d-flex flex-column justify-content-center text-center">
                            <h6 class="mb-2">Gizi Baik</h6>
                            <h2 class="fw-bold mb-0"><?php echo e($statistik['Gizi Baik']); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card h-100 bg-warning text-dark shadow-sm">
                        <div class="card-body d-flex flex-column justify-content-center text-center">
                            <h6 class="mb-2">Gizi Kurang</h6>
                            <h2 class="fw-bold mb-0"><?php echo e($statistik['Gizi Kurang']); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card h-100 bg-danger text-white shadow-sm">
                        <div class="card-body d-flex flex-column justify-content-center text-center">
                            <h6 class="mb-2">Gizi Buruk</h6>
                            <h2 class="fw-bold mb-0"><?php echo e($statistik['Gizi Buruk']); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card h-100 bg-info text-white shadow-sm">
                        <div class="card-body d-flex flex-column justify-content-center text-center">
                            <h6 class="mb-2">Gizi Lebih</h6>
                            <h2 class="fw-bold mb-0"><?php echo e($statistik['Gizi Lebih']); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <?php if(Auth::user()->role === 'orang_tua'): ?>
        <div class="col-xxl-12 col-sm-12">

        </div>

        <div class="row gx-3">
            <div class="col-xl-8 col-sm-12">

                <!-- Row starts -->
                <div class="row gx-3">
                    <div class="col-sm-12">
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title">Jadwal Pemeriksaan</h5>
                            </div>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $anakSaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-3">
                                        <div class="table-responsive">
                                            <table class="table m-0 align-middle dataTable no-footer">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Nama</th>
                                                        <th>Tanggal Pemeriksaan</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $anak->jadwalKunjungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td><?php echo e($index + 1); ?></td>
                                                            <td><?php echo e($anak->nama); ?></td>
                                                            <td><?php echo e(\Carbon\Carbon::parse($jadwal->tanggal_kunjungan)->format('d M Y')); ?></td>
                                                            <td>
                                                                <span class="badge 
                                                                    <?php echo e($jadwal->status === 'Hadir' ? 'bg-success' : ($jadwal->status === 'Tidak Hadir' ? 'bg-danger' : 'bg-warning')); ?>">
                                                                    <?php echo e($jadwal->status); ?>

                                                                </span>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="3" class="text-center">Belum ada jadwal kunjungan</td>
                                                        </tr>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
                <!-- Row ends -->
            </div>
            <div class="col-xl-4 col-sm-12">

                <!-- Row starts -->
                <div class="row gx-3">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $anakSaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-12 mb-3">
                            <div class="card border-0 shadow-lg rounded-4 h-100">
                                
                                <div class="card-header border-0 rounded-top-4">
                                    <h5 class="fw-bold mb-0 text-primary">👶 <?php echo e($anak->nama); ?></h5>
                                    <small class="text-muted">
                                        Lahir: <?php echo e(\Carbon\Carbon::parse($anak->tanggal_lahir)->format('d-m-Y')); ?> | Umur: <?php echo e(hitungUmur($anak->tanggal_lahir)); ?>

                                    </small>
                                    <hr>
                                </div>

                                
                                <div class="card-body">
                                    <!--[if BLOCK]><![endif]--><?php if($anak->pemeriksaan->isNotEmpty()): ?>
                                        <?php $last = $anak->pemeriksaan->first(); ?>
                                        <p class="mb-2"><strong>Status Gizi:</strong> 
                                            <span class="badge badge-sm px-3 py-2 fs-6
                                                <?php if($last->status_bbu == 'Gizi Baik'): ?> bg-success 
                                                <?php elseif($last->status_bbu == 'Gizi Kurang'): ?> bg-warning text-dark
                                                <?php elseif($last->status_bbu == 'Gizi Buruk'): ?> bg-danger 
                                                <?php else: ?> bg-info <?php endif; ?>">
                                                <?php echo e($last->status_bbu); ?>

                                            </span>
                                        </p>

                                        
                                        <div class="table-responsive">
                                            <table class="table table-sm table-borderless mb-0">
                                                <tr>
                                                    <th width="45%">Tgl Periksa</th>
                                                    <td>: <?php echo e(\Carbon\Carbon::parse($last->tanggal)->format('d-m-Y')); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Berat</th>
                                                    <td>: <?php echo e($last->berat_badan); ?> kg</td>
                                                </tr>
                                                <tr>
                                                    <th>Tinggi</th>
                                                    <td>: <?php echo e($last->tinggi_badan); ?> cm</td>
                                                </tr>
                                                <tr>
                                                    <th>Lingkar Kepala</th>
                                                    <td>: <?php echo e($last->lingkar_kepala ?? '-'); ?> cm</td>
                                                </tr>
                                                <tr>
                                                    <th>Catatan</th>
                                                    <td>: <em><?php echo e($last->catatan ?? 'Tidak ada'); ?></em></td>
                                                </tr>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-light text-muted py-2">
                                            <em>Belum ada data pemeriksaan</em>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                
                                <div class="card-footer bg-white border-0 d-flex justify-content-end">
                                    <a href="<?php echo e(route('orangtua.tindak-lanjut')); ?>" class="btn btn-sm btn-outline-primary rounded-pill">
                                        📊 Notifikasi
                                    </a>
                                    <a href="<?php echo e(route('konsultasi.index', $anak->id)); ?>" class="btn btn-sm btn-primary rounded-pill">
                                        💬 Konsultasi
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12">
                            <div class="alert alert-info shadow-sm">Belum ada data anak terdaftar.</div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <!-- Row ends -->

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/home/home-index.blade.php ENDPATH**/ ?>