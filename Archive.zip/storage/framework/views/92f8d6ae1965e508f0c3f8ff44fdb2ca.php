<!-- Row starts -->
<div class="row gx-3">
    <div class="col-sm-12">
        
        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="alert bg-success text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i style="color: white" class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i>
                <?php echo e(session('success')); ?>.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('error')): ?>
            <div class="alert bg-danger text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i style="color: white" class="ri-close-circle-line fs-3 me-2 lh-1"></i>
                <?php echo e(session('error')); ?>.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <div class="card">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="card-title mb-0">Standar Pertumbuhan</h5>

                <div class="d-flex gap-2">
                    <input type="text" class="form-control" 
                        placeholder="Cari berdasarkan usia..."
                        wire:model.live="search">

                    <a href="<?php echo e(route('standar-pertumbuhan.create')); ?>" class="btn btn-primary">Tambah</a>
                </div>
            </div>

            <div class="card-body pt-0">
                <!-- Table starts -->
                <div class="table-responsive">
                    <table class="table truncate m-0 align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Jenis Kelamin</th>
                                <th class="text-center">Usia (bulan)</th>
                                <th class="text-center">BB (min - max)</th>
                                <th class="text-center">TB (min - max)</th>
                                <th class="text-center">LK (min - max)</th>
                                <th class="text-center">LL (min - max)</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $standarList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($row->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                                    <td class="text-center">
                                        <span class="badge border border-primary text-primary"><?php echo e($row->usia_bulan); ?></span>
                                    </td>
                                    <td class="text-center"><?php echo e($row->bb_min); ?> - <?php echo e($row->bb_max); ?></td>
                                    <td class="text-center"><?php echo e($row->tb_min); ?> - <?php echo e($row->tb_max); ?></td>
                                    <td class="text-center"><?php echo e($row->lk_min); ?> - <?php echo e($row->lk_max); ?></td>
                                    <td class="text-center"><?php echo e($row->ll_min); ?> - <?php echo e($row->ll_max); ?></td>
                                    <td>
                                        <div class="d-inline-flex gap-1">
                                            <a href="<?php echo e(route('standar-pertumbuhan.edit', $row->id)); ?>" class="btn btn-success btn-sm"
                                                data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit Data">
                                                <i class="ri-edit-box-line"></i>
                                            </a>
                                            <button type="button" wire:click.prevent="deleteConfirmation('<?php echo e($row->id); ?>')" 
                                                class="btn btn-danger btn-sm" 
                                                data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Hapus Data">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center p-4 text-gray-500">Belum ada data standar pertumbuhan</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
                <!-- Table ends -->
            </div>
        </div>
    </div>
</div>
<!-- Row ends -->
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/standar-pertumbuhan/sp-index.blade.php ENDPATH**/ ?>