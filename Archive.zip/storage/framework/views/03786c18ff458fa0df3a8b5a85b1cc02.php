<div>
    <h4>Edit Konsultasi</h4>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="update">
        <div class="mb-3">
            <label>Nama Anak</label>

            <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role === 'orang_tua'): ?>
                
                <input type="text" 
                       class="form-control" 
                       value="<?php echo e(\App\Models\Anak::find($anak_id)?->nama); ?>" 
                       disabled>
                <input type="hidden" wire:model="anak_id"> 
            <?php else: ?>
                
                <select class="form-control" wire:model="anak_id">
                    <option value="">-- pilih anak --</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $anakList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($anak->id); ?>"><?php echo e($anak->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['anak_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mb-3">
            <label for="keluhan">Keluhan</label>
            <textarea wire:model="keluhan" id="keluhan" rows="3" class="form-control"></textarea>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['keluhan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <button class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('konsultasi.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/konsultasi/edit.blade.php ENDPATH**/ ?>