<div class="row gx-3">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Tambah Data Anak</h5>
            </div>
            <div class="card-body">

                <form wire:submit.prevent="store">

                    <div class="mb-3">
                        <label class="form-label">Tanggal<span class="text-danger">*</span></label>
                        <input type="date" class="form-control" wire:model="tanggal">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Berat Badan (kg)<span class="text-danger">*</span></label>
                        <input type="number" step="0.1"  class="form-control" wire:model="berat_badan">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['berat_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tinggi Badan (cm)<span class="text-danger">*</span></label>
                        <input type="number" step="0.1"  class="form-control" wire:model="tinggi_badan">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tinggi_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Lingkar Kepala (cm)<span class="text-danger">*</span></label>
                        <input type="number" step="0.1"  class="form-control" wire:model="lingkar_kepala">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['lingkar_kepala'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Lingkar Lengan (cm)<span class="text-danger">*</span></label>
                        <input type="number" step="0.1"  class="form-control" wire:model="lingkar_lengan">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['lingkar_lengan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Tombol -->
                    <div class="d-flex gap-2 justify-content-end">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/pustu/riwayat-posyandu/posyandu-create.blade.php ENDPATH**/ ?>