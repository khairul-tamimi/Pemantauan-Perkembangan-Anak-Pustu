<!-- Row starts -->
<div class="row gx-3">
    <div class="col-sm-12">

        
        <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
            <div class="alert bg-success text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-checkbox-circle-line fs-3 me-2 lh-1"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('error')): ?>
            <div class="alert bg-danger text-white alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-close-circle-line fs-3 me-2 lh-1"></i> <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php if(session()->has('warning')): ?>
            <div class="alert bg-warning text-dark alert-dismissible d-flex align-items-center fade show" role="alert">
                <i class="ri-alert-line fs-3 me-2 lh-1"></i> <?php echo e(session('warning')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="card shadow-sm rounded-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="card-title mb-0">
                    List User 
                    <span class="badge border border-primary text-primary"></span>
                </h5>

                <div class="d-flex gap-2">
                <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin'])): ?>
                    <input type="text" class="form-control"
                           placeholder="Cari..."
                           wire:model.live="search">
                    
                    
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Tambah</a>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <div class="card-body pt-0">
                <!-- Table starts -->
                <div class="table-responsive">
                    <table class="table m-0 align-middle dataTable no-footer">
                        <thead>
                            <tr>
                                <th>Foto</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th width="150">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($user->foto): ?>
                                            <img src="<?php echo e(asset('storage/'.$user->foto)); ?>" 
                                                 alt="foto" class="rounded-circle" width="40" height="40">
                                        <?php else: ?>
                                            <span class="badge bg-secondary">N/A</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><span class="badge bg-info"><?php echo e(ucfirst($user->role)); ?></span></td>
                                    <td>
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-info btn-sm"
                                                data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Edit Data">
                                                <i class="ri-edit-box-line"></i>
                                            </a>
                                        <!--[if BLOCK]><![endif]--><?php if(in_array(Auth::user()->role, ['admin'])): ?>
                                            <button type="button" wire:click.prevent="deleteConfirmation('<?php echo e($user->id); ?>')"
                                                class="btn btn-danger btn-sm" data-bs-toggle="tooltip" data-bs-placement="top"
                                                data-bs-title="Hapus Data">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted">Tidak ada data user</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>
                <!-- Table ends -->

                
                <div class="mt-3">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- Row ends -->
<?php /**PATH /Users/dev4site/Project/pustu/resources/views/livewire/user/user-index.blade.php ENDPATH**/ ?>